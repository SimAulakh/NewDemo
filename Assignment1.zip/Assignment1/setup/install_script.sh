#!/bin/bash

sudo cp selinux_config /etc/selinux/config

sudo useradd todoapp
echo ""
echo "Installing git..."
sudo dnf install -y git
echo ""
echo "Installed git √"

echo ""
echo "Logging in as todoapp user and cloning repo..."
sudo su - todoapp bash -c "git clone https://github.com/timoguic/ACIT4640-todo-app.git /home/todoapp/app"
echo ""
echo "Repository cloned √"

echo ""
echo "Downloading NodeJS..."
curl -sL https://rpm.nodesource.com/setup_14.x | sudo bash -
echo ""
echo "Installing NodeJS..."
sudo dnf install -y nodejs
echo ""
echo "NodeJS installed √"

echo ""
echo "Configuring MongoDB settings..."
sudo -i bash -c "rm -f /etc/yum.repos.d/mongodb-org-4.4.repo"
sudo -i bash -c "printf \"[mongodb-org-4.4]\nname=MongoDB Repository\nbaseurl=https://repo.mongodb.org/yum/redhat/\"$'\x24'\"releasever/mongodb-org/4.4/x86_64/\ngpgcheck=1\nenabled=1\ngpgkey=https://www.mongodb.org/static/pgp/server-4.4.asc\" > /etc/yum.repos.d/mongodb-org-4.4.repo"
echo ""
echo "Settings configured √"

echo ""
echo "Installing Mongo-db..."
sudo -i yum install -y mongodb-org
echo ""
echo "Mongodb installed √"
echo ""
echo "Starting mongod service..."
sudo -i systemctl start mongod
sudo -i setenforce 0
sudo -i firewall-cmd --zone=public --add-port=8080/tcp
sudo -i firewall-cmd --runtime-to-permanent

echo ""
echo "Installing node modules..."
sudo su - todoapp bash -c "rm -f /home/todoapp/app/config/database.js"
sudo su - todoapp bash -c "printf \"module.exports = {\nlocalUrl: 'mongodb://localhost/acit4640'\n};\" > /home/todoapp/app/config/database.js"
sudo su - todoapp bash -c "npm install --prefix /home/todoapp/app/"

sudo -i bash -c "rm -f /etc/systemd/system/todoapp.service"
sudo -i bash -c "printf \"[Unit]\nDescription=Todo app, ACIT4640\nAfter=network.target\nRequires=mongod.service\n[Service]\nEnvironment=NODE_PORT=8080\nWorkingDirectory=/home/todoapp/app\nType=simple\nUser=todoapp\nExecStartPre=/bin/sleep 10\nExecStart=/usr/bin/node /home/todoapp/app/server.js\nRestart=always\n[Install]\nWantedBy=multi-user.target\" > /etc/systemd/system/todoapp.service"

sudo -i dnf install -y epel-release
sudo -i dnf install -y nginx
sudo -i sed -i -e 's~/usr/share/nginx/html~/home/todoapp/app/public~' /etc/nginx/nginx.conf
sudo -i sed -i -e 's~# Load configuration files for the default server block.~location /api/todos {proxy_pass http://localhost:8080;}~' /etc/nginx/nginx.conf

sudo su - todoapp bash -c "chmod a+rx /home/todoapp/"

sudo systemctl stop nginx
sudo systemctl enable nginx
sudo systemctl start nginx
sudo systemctl enable todoapp
sudo systemctl restart todoapp

sudo systemctl reboot