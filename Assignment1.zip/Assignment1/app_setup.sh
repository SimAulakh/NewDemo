#!/bin/bash -x

scp selinux_config todoapp:
scp -r setup/ todoapp:
ssh todoapp bash setup/install_script.sh